import functools
from absl import logging
import numpy as np
import tensorflow as tf

import dataloader
import hparams_config
import utils
from backbone import backbone_factory
from backbone import efficientnet_builder
from keras import fpn_configs
from keras import postprocess
from keras import util_keras


class ProtoNet(tf.keras.layers.Layer):
    """Box regression network."""

    def __init__(self,
                 num_filters=32,
                 is_training_bn=False,
                 act_type='swish',
                 repeats=5,
                 use_sam=False,
                 separable_conv=True,
                 strategy=None,
                 data_format='channels_last',
                 resize_type='nearest',
                 name='proto_net',
                 **kwargs):
        """Initialize CoefNet.

        Args:

          num_filters: number of filters for "intermediate" layers.
          min_level: minimum level for features.
          max_level: maximum level for features.
          is_training_bn: True if we train the BatchNorm.
          act_type: String of the activation used.
          repeats: number of "intermediate" layers.
          separable_conv: True to use separable_conv instead of conv2D.
          survival_prob: if a value is set then drop connect will be used.
          strategy: string to specify training strategy for TPU/GPU/CPU.
          data_format: string of 'channel_first' or 'channels_last'.
          name: Name of the layer.
          **kwargs: other parameters.
        """

        super().__init__(name=name, **kwargs)

        self.num_filters = num_filters

        self.repeats = repeats
        self.separable_conv = separable_conv
        self.is_training_bn = is_training_bn

        self.act_type = act_type
        self.strategy = strategy
        self.data_format = data_format
        self.use_sam = use_sam

        self.conv_ops = []
        self.bns = []

        self.upsample2d = tf.keras.layers.UpSampling2D((2, 2),
                                                       data_format=self.data_format,
                                                       interpolation=resize_type)

        self.spatialAttentionConv = tf.keras.layers.Conv2D(
            filters=1,
            kernel_initializer=tf.random_normal_initializer(stddev=0.01),
            data_format=self.data_format,
            kernel_size=3,
            activation='sigmoid',
            use_bias=False,
            padding='same',
            name='sam-conv')

        for i in range(self.repeats):
            if i == 4:
                num_filters = 32
            else:
                num_filters = self.num_filters

            # If using SeparableConv2D
            if self.separable_conv:
                self.conv_ops.append(
                    tf.keras.layers.SeparableConv2D(
                        filters=num_filters,
                        depth_multiplier=1,
                        pointwise_initializer=tf.initializers.VarianceScaling(),
                        depthwise_initializer=tf.initializers.VarianceScaling(),
                        data_format=self.data_format,
                        kernel_size=3,
                        activation=None,
                        bias_initializer=tf.zeros_initializer(),
                        padding='same',
                        name='proto-%d' % i))
            # If using Conv2d
            else:
                self.conv_ops.append(
                    tf.keras.layers.Conv2D(
                        filters=num_filters,
                        kernel_initializer=tf.random_normal_initializer(stddev=0.01),
                        data_format=self.data_format,
                        kernel_size=3,
                        activation=None,
                        bias_initializer=tf.zeros_initializer(),
                        padding='same',
                        name='proto-%d' % i))

            self.bns.append(
                util_keras.build_batch_norm(
                    is_training_bn=self.is_training_bn,
                    strategy=self.strategy,
                    data_format=self.data_format,
                    name='proto-bn-%d' % (i))
            )

    def call(self, image, training):
        """Call protonet."""
        for i in range(self.repeats):
            image = self.conv_ops[i](image)
            image = self.bns[i](image, training=training)
            if self.act_type:
                image = utils.activation_fn(image, self.act_type)
            if i == 2:
                if self.use_sam:
                    avg_out = tf.keras.backend.mean(image, axis=-1, keepdims=True)
                    max_out = tf.keras.backend.max(image, axis=-1, keepdims=True)
                    scale = tf.concat([avg_out, max_out], axis=-1)
                    scale = self.spatialAttentionConv(scale)
                    image = image * scale

                image = self.upsample2d(image)

        return image


class SegmentationHead(tf.keras.layers.Layer):
    """Keras layer for semantic segmentation head."""

    def __init__(self,
                 num_classes,
                 num_filters,
                 min_level,
                 max_level,
                 data_format,
                 is_training_bn,
                 act_type,
                 strategy,
                 separable_conv=True,
                 resize_type='nearest',
                 name='seg_net',
                 **kwargs):
        """Initialize SegmentationHead.

        Args:
          num_classes: number of classes.
          num_filters: number of filters for "intermediate" layers.
          min_level: minimum level for features.
          max_level: maximum level for features.
          data_format: string of 'channel_first' or 'channels_last'.
          is_training_bn: True if we train the BatchNorm.
          act_type: String of the activation used.
          strategy: string to specify training strategy for TPU/GPU/CPU.
          **kwargs: other parameters.
        """
        super().__init__(name=name, **kwargs)
        self.data_format = data_format
        self.act_type = act_type
        self.conv_ops = []
        self.bns = []
        self.separable_conv = separable_conv

        self.upsample2d = tf.keras.layers.UpSampling2D((2, 2), data_format=self.data_format,
                                                       interpolation=resize_type)

        for i in range(max_level - min_level):

            # If using SeparableConv2D
            if self.separable_conv:
                self.conv_ops.append(
                    tf.keras.layers.SeparableConv2D(
                        filters=num_filters,
                        depth_multiplier=1,
                        pointwise_initializer=tf.initializers.VarianceScaling(),
                        depthwise_initializer=tf.initializers.VarianceScaling(),
                        data_format=self.data_format,
                        kernel_size=3,
                        activation=None,
                        bias_initializer=tf.zeros_initializer(),
                        padding='same',
                        name='seg-%d' % (i))
                )
            # If using Conv2d
            else:
                self.conv_ops.append(
                    tf.keras.layers.Conv2D(
                        filters=num_filters,
                        kernel_initializer=tf.random_normal_initializer(stddev=0.01),
                        data_format=self.data_format,
                        kernel_size=3,
                        activation=None,
                        bias_initializer=tf.zeros_initializer(),
                        padding='same',
                        name='seg-%d' % (i))
                )
            self.bns.append(
                util_keras.build_batch_norm(
                    is_training_bn=is_training_bn,
                    data_format=data_format,
                    strategy=strategy,
                    name='seg-bn-%d' % (i)))

        if self.separable_conv:
            self.seg_conv = tf.keras.layers.SeparableConv2D(
                filters=num_classes,
                depth_multiplier=1,
                pointwise_initializer=tf.initializers.VarianceScaling(),
                depthwise_initializer=tf.initializers.VarianceScaling(),
                data_format=self.data_format,
                kernel_size=3,
                activation=None,
                bias_initializer=tf.zeros_initializer(),
                padding='same',
                name='seg-predict')
        else:
            self.seg_conv = tf.keras.layers.Conv2D(
                filters=num_classes,
                kernel_initializer=tf.random_normal_initializer(stddev=0.01),
                data_format=self.data_format,
                kernel_size=3,
                activation=None,
                bias_initializer=tf.zeros_initializer(),
                padding='same',
                name='seg-predict')

    def call(self, feats, training):
        x = feats[-1]

        skips = list(reversed(feats[:-1]))

        for con2d, bn, skip in zip(self.conv_ops, self.bns, skips):
            x = self.upsample2d(x)
            x = con2d(x)
            x = bn(x, training)
            x = utils.activation_fn(x, self.act_type)
            x = tf.concat([x, skip], axis=-1)

        # This is the last layer of the model
        x = self.upsample2d(x)
        x = self.seg_conv(x)
        return x


class SegNet(tf.keras.layers.Layer):
    """Box regression network."""

    def __init__(self,
                 num_classes,
                 is_training_bn=False,
                 act_type='swish',
                 separable_conv=True,
                 strategy=None,
                 data_format='channels_last',
                 name='semantic_net',
                 **kwargs):
        """Initialize CoefNet.

        Args:

          num_filters: number of filters for "intermediate" layers.
          min_level: minimum level for features.
          max_level: maximum level for features.
          is_training_bn: True if we train the BatchNorm.
          act_type: String of the activation used.
          repeats: number of "intermediate" layers.
          separable_conv: True to use separable_conv instead of conv2D.
          survival_prob: if a value is set then drop connect will be used.
          strategy: string to specify training strategy for TPU/GPU/CPU.
          data_format: string of 'channel_first' or 'channels_last'.
          name: Name of the layer.
          **kwargs: other parameters.
        """

        super().__init__(name=name, **kwargs)

        self.separable_conv = separable_conv
        self.is_training_bn = is_training_bn

        self.act_type = act_type
        self.strategy = strategy
        self.data_format = data_format

        # If using SeparableConv2D
        if self.separable_conv:
            self.conv_op = tf.keras.layers.SeparableConv2D(
                filters=num_classes,
                depth_multiplier=1,
                pointwise_initializer=tf.initializers.VarianceScaling(),
                depthwise_initializer=tf.initializers.VarianceScaling(),
                data_format=self.data_format,
                kernel_size=3,
                activation=None,
                bias_initializer=tf.zeros_initializer(),
                padding='same',
                name='semantic')
        # If using Conv2d
        else:
            self.conv_op = tf.keras.layers.Conv2D(
                filters=num_classes,
                kernel_initializer=tf.random_normal_initializer(stddev=0.01),
                data_format=self.data_format,
                kernel_size=1,
                activation=None,
                bias_initializer=tf.zeros_initializer(),
                padding='same',
                name='semantic')

    def call(self, image, training):
        """Call protonet."""

        image = self.conv_op(image)
        return image


class CoefNet(tf.keras.layers.Layer):
    """Box regression network."""

    def __init__(self,
                 num_anchors=9,
                 num_filters=32,
                 min_level=3,
                 max_level=7,
                 is_training_bn=False,
                 act_type='swish',
                 repeats=4,
                 separable_conv=True,
                 survival_prob=None,
                 strategy=None,
                 data_format='channels_last',
                 name='coef_net',
                 **kwargs):
        """Initialize CoefNet.

        Args:
          num_anchors: number of  anchors used.
          num_filters: number of filters for "intermediate" layers.
          min_level: minimum level for features.
          max_level: maximum level for features.
          is_training_bn: True if we train the BatchNorm.
          act_type: String of the activation used.
          repeats: number of "intermediate" layers.
          separable_conv: True to use separable_conv instead of conv2D.
          survival_prob: if a value is set then drop connect will be used.
          strategy: string to specify training strategy for TPU/GPU/CPU.
          data_format: string of 'channel_first' or 'channels_last'.
          name: Name of the layer.
          **kwargs: other parameters.
        """

        super().__init__(name=name, **kwargs)

        self.num_anchors = num_anchors
        self.num_filters = num_filters
        self.min_level = min_level
        self.max_level = max_level
        self.repeats = repeats
        self.separable_conv = separable_conv
        self.is_training_bn = is_training_bn
        self.survival_prob = survival_prob
        self.act_type = act_type
        self.strategy = strategy
        self.data_format = data_format

        self.conv_ops = []
        self.bns = []
        # self.out_activation =

        for i in range(self.repeats):
            # If using SeparableConv2D
            if self.separable_conv:
                self.conv_ops.append(
                    tf.keras.layers.SeparableConv2D(
                        filters=self.num_filters,
                        depth_multiplier=1,
                        pointwise_initializer=tf.initializers.VarianceScaling(),
                        depthwise_initializer=tf.initializers.VarianceScaling(),
                        data_format=self.data_format,
                        kernel_size=3,
                        activation=None,
                        bias_initializer=tf.zeros_initializer(),
                        padding='same',
                        name='mask-coef-%d' % i))
            # If using Conv2d
            else:
                self.conv_ops.append(
                    tf.keras.layers.Conv2D(
                        filters=self.num_filters,
                        kernel_initializer=tf.random_normal_initializer(stddev=0.01),
                        data_format=self.data_format,
                        kernel_size=3,
                        activation=None,
                        bias_initializer=tf.zeros_initializer(),
                        padding='same',
                        name='mask-coef-%d' % i))

            bn_per_level = []
            for level in range(self.min_level, self.max_level + 1):
                bn_per_level.append(
                    util_keras.build_batch_norm(
                        is_training_bn=self.is_training_bn,
                        strategy=self.strategy,
                        data_format=self.data_format,
                        name='mask-coef-%d-bn-%d' % (i, level)))
            self.bns.append(bn_per_level)

        if self.separable_conv:
            self.coefs = tf.keras.layers.SeparableConv2D(
                filters=32 * self.num_anchors,
                depth_multiplier=1,
                pointwise_initializer=tf.initializers.VarianceScaling(),
                depthwise_initializer=tf.initializers.VarianceScaling(),
                data_format=self.data_format,
                kernel_size=3,
                activation=None,
                bias_initializer=tf.zeros_initializer(),
                padding='same',
                name='coef-predict')
        else:
            self.coefs = tf.keras.layers.Conv2D(
                filters=32 * self.num_anchors,
                kernel_initializer=tf.random_normal_initializer(stddev=0.01),
                data_format=self.data_format,
                kernel_size=3,
                activation=None,
                bias_initializer=tf.zeros_initializer(),
                padding='same',
                name='coef-predict')

    def call(self, inputs, training):
        """Call coefnet."""
        coef_outputs = []
        for level_id in range(0, self.max_level - self.min_level + 1):
            image = inputs[level_id]
            for i in range(self.repeats):
                original_image = image
                image = self.conv_ops[i](image)
                image = self.bns[i][level_id](image, training=training)
                if self.act_type:
                    image = utils.activation_fn(image, self.act_type)
                if i > 0 and self.survival_prob:
                    image = utils.drop_connect(image, training, self.survival_prob)
                    image = image + original_image

            coef_outputs.append(tf.nn.tanh(self.coefs(image), name='coef-predict-tanh'))

        return coef_outputs
