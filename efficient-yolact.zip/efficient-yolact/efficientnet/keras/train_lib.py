# Copyright 2020 Google Research. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Training related libraries."""
from concurrent import futures
import math
import re
import os
from absl import logging
import numpy as np
import tensorflow as tf


import PIL.ImageColor as ImageColor
from visualize import vis_utils

import inference
import iou_utils
import utils

from keras import anchors
from keras import efficientdet_keras
from keras import label_util
from keras import util_keras
from object_detection import shape_utils
from tensorflow.python.keras import backend as K
from tensorflow.python.util.tf_export import keras_export


def update_learning_rate_schedule_parameters(params):
    """Updates params that are related to the learning rate schedule."""
    batch_size = params['batch_size'] * params['num_shards']
    # Learning rate is proportional to the batch size
    params['adjusted_learning_rate'] = (params['learning_rate'] * batch_size / 64)
    steps_per_epoch = params['steps_per_epoch']
    params['lr_warmup_step'] = int(params['lr_warmup_epoch'] * steps_per_epoch)
    params['first_lr_drop_step'] = int(params['first_lr_drop_epoch'] *
                                       steps_per_epoch)
    params['second_lr_drop_step'] = int(params['second_lr_drop_epoch'] *
                                        steps_per_epoch)
    params['total_steps'] = int(params['num_epochs'] * steps_per_epoch)


class StepwiseLrSchedule(tf.optimizers.schedules.LearningRateSchedule):
    """Stepwise learning rate schedule."""

    def __init__(self, adjusted_lr: float, lr_warmup_init: float,
                 lr_warmup_step: int, first_lr_drop_step: int,
                 second_lr_drop_step: int):
        """Build a StepwiseLrSchedule.

        Args:
          adjusted_lr: `float`, The initial learning rate.
          lr_warmup_init: `float`, The warm up learning rate.
          lr_warmup_step: `int`, The warm up step.
          first_lr_drop_step: `int`, First lr decay step.
          second_lr_drop_step: `int`, Second lr decay step.
        """
        super().__init__()
        logging.info('LR schedule method: stepwise')
        self.adjusted_lr = adjusted_lr
        self.lr_warmup_init = lr_warmup_init
        self.lr_warmup_step = lr_warmup_step
        self.first_lr_drop_step = first_lr_drop_step
        self.second_lr_drop_step = second_lr_drop_step

    def __call__(self, step):
        linear_warmup = (
                self.lr_warmup_init +
                (tf.cast(step, dtype=tf.float32) / self.lr_warmup_step *
                 (self.adjusted_lr - self.lr_warmup_init)))
        learning_rate = tf.where(step < self.lr_warmup_step, linear_warmup,
                                 self.adjusted_lr)
        lr_schedule = [[1.0, self.lr_warmup_step], [0.1, self.first_lr_drop_step],
                       [0.01, self.second_lr_drop_step]]
        for mult, start_global_step in lr_schedule:
            learning_rate = tf.where(step < start_global_step, learning_rate,
                                     self.adjusted_lr * mult)
        return learning_rate


class CosineLrSchedule(tf.optimizers.schedules.LearningRateSchedule):
    """Cosine learning rate schedule."""

    def __init__(self, adjusted_lr: float, lr_warmup_init: float,
                 lr_warmup_step: int, total_steps: int):
        """Build a CosineLrSchedule.

        Args:
          adjusted_lr: `float`, The initial learning rate.
          lr_warmup_init: `float`, The warm up learning rate.
          lr_warmup_step: `int`, The warm up step.
          total_steps: `int`, Total train steps.
        """
        super().__init__()
        logging.info('LR schedule method: cosine')
        self.adjusted_lr = adjusted_lr
        self.lr_warmup_init = lr_warmup_init
        self.lr_warmup_step = lr_warmup_step
        self.decay_steps = tf.cast(total_steps - lr_warmup_step, tf.float32)

    def __call__(self, step):
        linear_warmup = (
                self.lr_warmup_init +
                (tf.cast(step, dtype=tf.float32) / self.lr_warmup_step *
                 (self.adjusted_lr - self.lr_warmup_init)))
        cosine_lr = 0.5 * self.adjusted_lr * (
                1 + tf.cos(math.pi * tf.cast(step, tf.float32) / self.decay_steps))

        return tf.where(step < self.lr_warmup_step, linear_warmup, cosine_lr)


class PolynomialLrSchedule(tf.optimizers.schedules.LearningRateSchedule):
    """Polynomial learning rate schedule."""

    def __init__(self, adjusted_lr: float, lr_warmup_init: float,
                 lr_warmup_step: int, power: float, total_steps: int):
        """Build a PolynomialLrSchedule.

        Args:
          adjusted_lr: `float`, The initial learning rate.
          lr_warmup_init: `float`, The warm up learning rate.
          lr_warmup_step: `int`, The warm up step.
          power: `float`, power.
          total_steps: `int`, Total train steps.
        """
        super().__init__()
        logging.info('LR schedule method: polynomial')
        self.adjusted_lr = adjusted_lr
        self.lr_warmup_init = lr_warmup_init
        self.lr_warmup_step = lr_warmup_step
        self.power = power
        self.total_steps = total_steps

    def __call__(self, step):
        linear_warmup = (
                self.lr_warmup_init +
                (tf.cast(step, dtype=tf.float32) / self.lr_warmup_step *
                 (self.adjusted_lr - self.lr_warmup_init)))
        polynomial_lr = self.adjusted_lr * tf.pow(
            1 - (tf.cast(step, dtype=tf.float32) / self.total_steps), self.power)
        return tf.where(step < self.lr_warmup_step, linear_warmup, polynomial_lr)


def learning_rate_schedule(params):
    """Learning rate schedule based on global step."""
    update_learning_rate_schedule_parameters(params)
    lr_decay_method = params['lr_decay_method']
    if lr_decay_method == 'stepwise':
        return StepwiseLrSchedule(params['adjusted_learning_rate'],
                                  params['lr_warmup_init'],
                                  params['lr_warmup_step'],
                                  params['first_lr_drop_step'],
                                  params['second_lr_drop_step'])

    if lr_decay_method == 'cosine':
        return CosineLrSchedule(params['adjusted_learning_rate'],
                                params['lr_warmup_init'], params['lr_warmup_step'],
                                params['total_steps'])

    if lr_decay_method == 'polynomial':
        return PolynomialLrSchedule(params['adjusted_learning_rate'],
                                    params['lr_warmup_init'],
                                    params['lr_warmup_step'],
                                    params['poly_lr_power'], params['total_steps'])

    raise ValueError('unknown lr_decay_method: {}'.format(lr_decay_method))


def get_optimizer(params):
    """Get optimizer."""
    learning_rate = learning_rate_schedule(params)
    if params['optimizer'].lower() == 'sgd':
        logging.info('Use SGD optimizer')
        optimizer = tf.keras.optimizers.SGD(
            learning_rate, momentum=params['momentum'])
    elif params['optimizer'].lower() == 'adam':
        logging.info('Use Adam optimizer')
        optimizer = tf.keras.optimizers.Adam(learning_rate)
    else:
        raise ValueError('optimizers should be adam or sgd')

    moving_average_decay = params['moving_average_decay']
    if moving_average_decay:
        # TODO(tanmingxing): potentially add dynamic_decay for new tfa release.
        import tensorflow_addons as tfa  # pylint: disable=g-import-not-at-top
        optimizer = tfa.optimizers.MovingAverage(
            optimizer, average_decay=moving_average_decay)
    if params['mixed_precision']:
        optimizer = tf.keras.mixed_precision.experimental.LossScaleOptimizer(
            optimizer, loss_scale='dynamic')
    return optimizer


class DisplayCallback(tf.keras.callbacks.Callback):
    """Display inference result callback."""

    def __init__(self, sample_image, output_dir, update_freq=1):
        super().__init__()
        self.file_list = []
        for f in tf.io.gfile.glob(sample_image):
            image_file = tf.io.read_file(f)
            image_tf = tf.expand_dims(tf.image.decode_jpeg(image_file, channels=3), axis=0)
            self.file_list.append(image_tf)

        self.executor = futures.ThreadPoolExecutor(max_workers=1)
        self.update_freq = update_freq
        self.output_dir = output_dir

    def set_model(self, model: tf.keras.Model):
        self.train_model = model
        with tf.device('/cpu:0'):
            self.model = efficientdet_keras.EfficientDetModel(config=model.config)
        height, width = utils.parse_image_size(model.config.image_size)
        self.model.build((1, height, width, 3))
        self.file_writer = tf.summary.create_file_writer(self.output_dir)
        self.min_score_thresh = self.model.config.nms_configs['score_thresh'] or 0.4
        self.max_boxes_to_draw = self.model.config.nms_configs['max_output_size'] or 100

    def on_epoch_end(self, epoch, logs=None):
        if epoch % self.update_freq == 0:
            self.executor.submit(self.draw_inference, epoch)

    @tf.function
    def inference(self, img):
        return self.model(img, training=False)

    def draw_semantic_mask(self, semantic_masks):
        h, w = semantic_masks.shape
        out_mask = np.zeros([h, w, 3], dtype=np.uint8)

        for i in range(1, self.model.config.num_classes + 1):
            color = ImageColor.getrgb(vis_utils.STANDARD_COLORS[i])
            color = np.reshape(list(color), [1, 1, 3])

            out_mask[semantic_masks == i, :] = color
        return out_mask

    def draw_inference(self, epoch):
        # print('\n cur Learnning rate', K.get_value(self.train_model.optimizer.lr))

        self.model.set_weights(self.train_model.get_weights())

        # if self.model.config.num_classes == 8:
        #     id_label_mapping = coco_8classes_id_mapping
        # else:
        #     id_label_mapping = None
        for i, img in enumerate(self.file_list):
            boxes, scores, classes, valid_len, instance_masks, semantic_masks = self.inference(img)
            length = valid_len[0]
            image = inference.visualize_image(
                img[0],
                boxes[0].numpy()[:length],
                classes[0].numpy().astype(np.int)[:length],
                scores[0].numpy()[:length],
                label_map=label_util.get_label_map(self.model.config.label_map),
                min_score_thresh=self.min_score_thresh,
                max_boxes_to_draw=self.max_boxes_to_draw,
                instance_masks=instance_masks[0].numpy()[:length])

            with self.file_writer.as_default():
                # tf.summary.image('Test-image-%d' % (i), tf.expand_dims(image, axis=0), step=epoch)

                # semantic_masks = tf.expand_dims(semantic_masks, axis=-1)
                # semantic_masks = tf.tile(semantic_masks,(1,1,1,3))
                # semantic_masks = semantic_masks*27

                semantic_mask = self.draw_semantic_mask(semantic_masks[0])
                semantic_mask = tf.expand_dims(semantic_mask, axis=0)
                image_ = tf.expand_dims(image, axis=0)
                image_ = tf.concat([image_, semantic_mask], axis=2)
                tf.summary.image('Test-mask-%d' % (i), image_, step=epoch)

                # tf.summary.scalar('Learnning rate', K.get_value(self.train_model.optimizer.lr))


class ModelSaveCallback(tf.keras.callbacks.ModelCheckpoint):
    def __init__(self,
                 filepath,
                 monitor='val_loss',
                 verbose=0,
                 save_best_only=False,
                 save_weights_only=False,
                 mode='auto',
                 save_freq='epoch',
                 # options=None,
                 ):
        super().__init__(filepath, monitor, verbose, save_best_only, save_weights_only, mode, save_freq)  # ,options)
        self.model_idx = 1
        self.ori_filepath = self.filepath

    def on_batch_end(self, batch, logs=None):
        if self._implements_train_batch_hooks():
            logs = logs or {}
            self._batches_seen_since_last_saving += 1
            if self._batches_seen_since_last_saving >= self.save_freq:
                self.filepath = '%s-%d' % (self.ori_filepath, self.model_idx)
                self._save_model(epoch=self._current_epoch, logs=logs)
                self._batches_seen_since_last_saving = 0
        self.model_idx += 1


def get_callbacks(params, profile=False):
    tb_callback = tf.keras.callbacks.TensorBoard(
        log_dir=params['model_dir'], profile_batch=2 if profile else 0)  # , update_freq=200)
    ckpt_callback = tf.keras.callbacks.ModelCheckpoint(
        os.path.join(params['model_dir'], 'ep{epoch:03d}-model.h5'),
        # monitor='val_det_loss', verbose=1, save_best_only=True
    )
    # early_stopping = tf.keras.callbacks.EarlyStopping(
    #     monitor='val_loss', min_delta=0, patience=10, verbose=1)
    callbacks = [tb_callback, ckpt_callback]
    # callbacks = [tb_callback, ckpt_callback, early_stopping]
    if params.get('sample_image', None):
        callbacks.append(DisplayCallback(params.get('sample_image', None),
                                         os.path.join(params['model_dir'], 'train')))

    return callbacks


class FocalLoss(tf.keras.losses.Loss):
    """Compute the focal loss between `logits` and the golden `target` values.

    Focal loss = -(1-pt)^gamma * log(pt)
    where pt is the probability of being classified to the true class.
    """

    def __init__(self, alpha, gamma, label_smoothing=0.0, **kwargs):
        """Initialize focal loss.

        Args:
          alpha: A float32 scalar multiplying alpha to the loss from positive
            examples and (1-alpha) to the loss from negative examples.
          gamma: A float32 scalar modulating loss from hard and easy examples.
          label_smoothing: Float in [0, 1]. If > `0` then smooth the labels.
          **kwargs: other params.
        """
        super().__init__(**kwargs)
        self.alpha = alpha
        self.gamma = gamma
        self.label_smoothing = label_smoothing

    @tf.autograph.experimental.do_not_convert
    def call(self, y, y_pred):
        """Compute focal loss for y and y_pred.

        Args:
          y: A tuple of (normalizer, y_true), where y_true is the target class.
          y_pred: A float32 tensor [batch, height_in, width_in, num_predictions].

        Returns:
          the focal loss.
        """
        normalizer, y_true = y
        alpha = tf.convert_to_tensor(self.alpha, dtype=y_pred.dtype)
        gamma = tf.convert_to_tensor(self.gamma, dtype=y_pred.dtype)

        # compute focal loss multipliers before label smoothing, such that it will
        # not blow up the loss.
        pred_prob = tf.sigmoid(y_pred)
        p_t = (y_true * pred_prob) + ((1 - y_true) * (1 - pred_prob))
        alpha_factor = y_true * alpha + (1 - y_true) * (1 - alpha)
        modulating_factor = (1.0 - p_t) ** gamma

        # apply label smoothing for cross_entropy for each entry.
        y_true = y_true * (1.0 - self.label_smoothing) + 0.5 * self.label_smoothing
        ce = tf.nn.sigmoid_cross_entropy_with_logits(labels=y_true, logits=y_pred)

        # compute the final loss and return
        return alpha_factor * modulating_factor * ce / normalizer


class BoxLoss(tf.keras.losses.Loss):
    """L2 box regression loss."""

    def __init__(self, delta=0.1, **kwargs):
        """Initialize box loss.

        Args:
          delta: `float`, the point where the huber loss function changes from a
            quadratic to linear. It is typically around the mean value of regression
            target. For instances, the regression targets of 512x512 input with 6
            anchors on P3-P7 pyramid is about [0.1, 0.1, 0.2, 0.2].
          **kwargs: other params.
        """
        super().__init__(**kwargs)
        self.huber = tf.keras.losses.Huber(
            delta, reduction=tf.keras.losses.Reduction.NONE)

    @tf.autograph.experimental.do_not_convert
    def call(self, y_true, box_outputs):
        num_positives, box_targets = y_true
        normalizer = num_positives * 4.0
        mask = tf.cast(box_targets != 0.0, tf.float32)
        box_targets = tf.expand_dims(box_targets, axis=-1)
        box_outputs = tf.expand_dims(box_outputs, axis=-1)
        box_loss = self.huber(box_targets, box_outputs) * mask
        box_loss = tf.reduce_sum(box_loss)
        box_loss /= normalizer
        return box_loss


class BoxIouLoss(tf.keras.losses.Loss):
    """Box iou loss."""

    def __init__(self, iou_loss_type, min_level, max_level, num_scales,
                 aspect_ratios, anchor_scale, image_size, **kwargs):
        super().__init__(**kwargs)
        self.iou_loss_type = iou_loss_type
        self.input_anchors = anchors.Anchors(min_level, max_level, num_scales,
                                             aspect_ratios, anchor_scale,
                                             image_size)

    @tf.autograph.experimental.do_not_convert
    def call(self, y_true, box_outputs):
        anchor_boxes = tf.tile(
            self.input_anchors.boxes,
            [box_outputs.shape[0] // self.input_anchors.boxes.shape[0], 1])
        num_positives, box_targets = y_true
        box_outputs = anchors.decode_box_outputs(box_outputs, anchor_boxes)
        box_targets = anchors.decode_box_outputs(box_targets, anchor_boxes)
        normalizer = num_positives * 4.0
        box_iou_loss = iou_utils.iou_loss(box_outputs, box_targets,
                                          self.iou_loss_type)
        box_iou_loss = tf.reduce_sum(box_iou_loss) / normalizer
        return box_iou_loss


class MaskLoss(tf.keras.losses.Loss):
    """L2 box regression loss."""

    def __init__(self, **kwargs):
        """Initialize box loss.

        Args:
          **kwargs: other params.
        """
        super().__init__(**kwargs)

    @tf.autograph.experimental.do_not_convert
    def call(self, y_true, y_pred):
        ce = tf.nn.sigmoid_cross_entropy_with_logits(labels=y_true, logits=y_pred)
        return ce


class SemanticMaskLoss(tf.keras.losses.Loss):
    """L2 box regression loss."""

    def __init__(self, **kwargs):
        """Initialize box loss.

        Args:
          **kwargs: other params.
        """
        super().__init__(**kwargs)

    @tf.autograph.experimental.do_not_convert
    def call(self, y_true, y_pred):
        ce = tf.nn.sigmoid_cross_entropy_with_logits(labels=y_true, logits=y_pred)
        return ce

class LaplaceOperatorLoss(tf.keras.losses.Loss):
    """L2 loss"""

    def __init__(self, **kwargs):
        """Initialize laplace loss.

        Args:
            **kwargs: other params.
        """
        super().__init__(**kwargs)

    @tf.autograph.experimental.do_not_convert
    def call(self, y_true, y_pred):
        ce = tf.nn.l2_loss(y_true - y_pred)
        return ce


class EfficientDetNetTrain(efficientdet_keras.EfficientDetNet):
    """A customized trainer for EfficientDet.

    see https://www.tensorflow.org/guide/keras/customizing_what_happens_in_fit
    """

    # def _freeze_vars(self):
    #     if self.config.var_freeze_expr:
    #         return [
    #             v for v in self.trainable_variables
    #             if not re.match(self.config.var_freeze_expr, v.name)
    #         ]
    #     return self.trainable_variables

    def _freeze_vars(self):
        if self.config.var_freeze_expr:
            trainable_variables = []
            for var in self.trainable_variables:
                is_train = True
                for ptrn in self.config.var_freeze_expr:
                    if var.name.find(ptrn) >= 0:
                        is_train = False
                        break
                if is_train:
                    print('train var name, ', var.name)
                    # print('ptrn:', ptrn, var.name.find(ptrn))
                    trainable_variables.append(var)
                else:
                    print('freeze var name, ', var.name)

            return trainable_variables
        return self.trainable_variables

    def _reg_l2_loss(self, weight_decay, regex=r'.*(kernel|weight):0$'):
        """Return regularization l2 loss loss."""
        var_match = re.compile(regex)
        return weight_decay * tf.add_n([
            tf.nn.l2_loss(v)
            for v in self.trainable_variables
            if var_match.match(v.name)
        ])

    def _instance_dice_loss(self, pred, target, eps=1.):
        intersection = tf.reduce_sum(pred * target, axis=(1, 2))
        l = tf.reduce_sum(pred * pred, axis=(1, 2))
        r = tf.reduce_sum(target * target, axis=(1, 2))

        return 1.0 - tf.reduce_mean((2 * intersection + eps) / (l + r + eps))

    def _instance_mask_loss(self, pred_proto, pred_mask_coef, gt_masks, gt_boxes, anchors_match_gt_indices,
                            num_positives_sum,
                            use_multi_scale_proto,
                            use_crop_loss=False):

        pred_mask_h, pred_mask_w, mask_coef_k = pred_proto.get_shape().as_list()
        _, gt_mask_h, gt_mask_w, _ = gt_masks.get_shape().as_list()

        pos_indices = tf.squeeze(tf.where(tf.greater(anchors_match_gt_indices, -1)))
        pos_indices = tf.cast(tf.reshape(pos_indices, [-1]), tf.int32)

        mask_coef = tf.gather(pred_mask_coef, pos_indices)  # (n, k)

        gt_selected_indices = tf.gather(anchors_match_gt_indices, pos_indices)  # [n,]
        gt_mask_matched_anchor = tf.gather(gt_masks, gt_selected_indices)  # [n,H,W]
        gt_box_matched_anchor = tf.gather(gt_boxes, gt_selected_indices)  # [n,4]  #original value like 200,300

        gt_box_height_norm = (gt_box_matched_anchor[:, 2] - gt_box_matched_anchor[:, 0]) / gt_mask_h
        gt_box_width_norm = (gt_box_matched_anchor[:, 3] - gt_box_matched_anchor[:, 1]) / gt_mask_w

        gt_box_height = gt_box_height_norm * pred_mask_h
        gt_box_width = gt_box_width_norm * pred_mask_w

        gt_box_norm = gt_box_matched_anchor / gt_mask_h

        if use_multi_scale_proto == 2:
            mask_coef = tf.reshape(mask_coef, [-1, (int)(pred_mask_h / 16), (int)(pred_mask_w / 16),
                                               mask_coef_k, ])  # [n,h/4,w/4,k]
            mask_coef = tf.image.resize(mask_coef, (pred_mask_h, pred_mask_w))  # [n,h,w, k]
            mask_coef = tf.nn.softmax(mask_coef, axis=3)
            pred_proto = tf.expand_dims(pred_proto, axis=0)
            pred_mask = tf.reduce_sum(pred_proto * mask_coef, axis=3, keep_dims=True)  # [n,h,w, 1]
            pred_mask = tf.transpose(pred_mask, perm=(3, 0, 1, 2))  # [1,n,h,w]


        else:
            mask_coef = tf.reshape(mask_coef, [-1, mask_coef_k])  # (n, k)
            pred_mask = tf.matmul(pred_proto, mask_coef, transpose_a=False,
                                  transpose_b=True)  # [h,w,k]*[n,k](T) = [h,w,n]

            pred_mask = tf.transpose(pred_mask, perm=(2, 0, 1))  # [n,h,w]
            pred_mask = tf.expand_dims(pred_mask, axis=0)  # [n,h,w] -> [1,n,h,w]

        # gt_mask_matched_anchor = tf.expand_dims(gt_mask_matched_anchor, axis=3)  # [n,H,W, 1]
        resize_gt_masks = tf.image.resize(gt_mask_matched_anchor, (pred_mask_h, pred_mask_w))  # [n,h,w, 1]
        gt_mask = tf.transpose(resize_gt_masks, perm=(3, 0, 1, 2))  # [1,n,h,w]
        # mask_loss = tf.nn.sigmoid_cross_entropy_with_logits(labels=gt_mask, logits=pred_mask)  # [1,n,h,w]
        instance_mask_loss = self.loss['instance_mask_loss']
        mask_loss = instance_mask_loss(gt_mask, pred_mask)
        if use_crop_loss:
            mask_loss = util_keras.crop(mask_loss[0], gt_box_norm)
            mask_loss = tf.reduce_sum(mask_loss, axis=[1, 2]) / (gt_box_height * gt_box_width + 1)
        else:

            mask_loss = tf.reduce_sum(mask_loss[0], axis=[1, 2]) / (pred_mask_h * pred_mask_w) / (
                    gt_box_width_norm * gt_box_height_norm + 0.01)

        # mask_loss = tf.reduce_sum(mask_loss) / num_positives_sum
        #
        # mask_dice_loss = self._instance_dice_loss(pred_mask, gt_mask)
        #
        # return mask_loss + mask_dice_loss

        return tf.reduce_sum(mask_loss) / num_positives_sum

    def _semantic_segmentation_loss(self, pred_segment, gt_semantic_mask):
        # pred_segment(h,w,c) gt_semantic_mask (H,W,1)
        pred_h, pred_w, c = shape_utils.combined_static_and_dynamic_shape(pred_segment)

        gt_resize_mask = tf.image.resize(gt_semantic_mask, (pred_h, pred_w))

        gt_resize_mask = tf.cast(tf.reshape(gt_resize_mask, [-1]), dtype=tf.int32)
        gt_resize_mask = tf.one_hot(gt_resize_mask, c, on_value=1.0, off_value=0.0)
        # gt_resize_mask = tf.cast(tf.reshape(gt_resize_mask,[pred_h, pred_w, c]), dtype=tf.float32)

        pred_segment = tf.reshape(pred_segment, [-1, c])
        # print('gt_resize_mask shape', gt_resize_mask.shape)
        # print('pred_segment shape', pred_segment.shape)

        semantic_mask_loss = self.loss['semantic_mask_loss']
        mask_loss = semantic_mask_loss(gt_resize_mask, pred_segment)

        mask_loss = tf.reduce_sum(mask_loss) / (pred_h * pred_w)
        #print('semantic_loss type:',mask_loss.dtype)

        return mask_loss

    def _laplace_loss(self, pred_segment, gt_semantic_mask):
        # pred_segment(h,w,x) gt_semantic_mask (H,W,1)
        pred_h, pred_w, c = shape_utils.combined_static_and_dynamic_shape(pred_segment)
        gt_resize_mask = tf.image.resize(gt_semantic_mask, (pred_h, pred_w))
        pred_segment = tf.argmax(pred_segment, axis=2)
        pred_segment = tf.cast(pred_segment, dtype=tf.float32)
        pred_segment = tf.expand_dims(pred_segment, axis=2)
        smooth_value = [[1/27, 1/27, 1/27,],[1/27, 1/27, 1/27,],[1/27, 1/27, 1/27,]]
        # smooth_value = [1/27, 1/27, 1/27, 1/27, 1/27, 1/27, 1/27, 1/27, 1/27]
        smooth_init = tf.constant_initializer(smooth_value)
        #laplace_value = np.array([[0, 1, 0],[1, -4, 1],[0, 1, 0]]).astype(np.float32)
        laplace_value = [[0, 1, 0],[1, -4, 1],[0, 1, 0]]
        # laplace_value = [0, 1, 0, 1, -4, 1, 0, 1, 0]
        laplace_init = tf.constant_initializer(laplace_value)
        # smooth = tf.nn.conv2d(1, 3, use_bias=False, kernel_initializer=smooth_init, trainable=False)
        # laplace = tf.nn.conv2d(1, 3, use_bias=False, kernel_initializer=laplace_init, trainable=False)
        #smooth = tf.keras.layers.Conv2D(filters=1, kernel_size=3, use_bias=False, kernel_initializer=smooth_init, trainable=False)
        #laplace = tf.keras.layers.Conv2D(filters=1, kernel_size=3, use_bias=False, kernel_initializer=laplace_init, trainable=False)
        pred_segment = tf.expand_dims(pred_segment, axis=0)
        gt_resize_mask = tf.expand_dims(gt_resize_mask, axis=0)
        #print(pred_segment.dtype)

        pred_segment = self.smooth(pred_segment)
        pred_segment = self.smooth(pred_segment)
        pred_segment = self.smooth(pred_segment)
        pred_segment = self.laplace(pred_segment)

        gt_resize_mask = self.smooth(gt_resize_mask)
        gt_resize_mask = self.smooth(gt_resize_mask)
        gt_resize_mask = self.smooth(gt_resize_mask)
        gt_resize_mask = self.laplace(gt_resize_mask)


        laplace_operator_loss = self.loss['laplace_loss']
        laplace_loss = laplace_operator_loss(gt_resize_mask, pred_segment)
        #print('laplace_loss type:', laplace_loss.dtype)

        return laplace_loss

    def _semantic_segmentation_with_laplace_loss(self, pred_segment, gt_semantic_mask):
        semantic_loss = self._semantic_segmentation_loss(pred_segment, gt_semantic_mask)
        laplace_loss = self._laplace_loss(pred_segment, gt_semantic_mask)
        semantic_loss = tf.cast(semantic_loss, dtype=tf.float32)
        #print('laplace_loss type:', laplace_loss.dtype)
        laplace_loss = tf.cast(laplace_loss, dtype=tf.float32)
        #print('semantic_loss type:', semantic_loss.dtype)
        overall_loss = tf.add(0.5*semantic_loss , 0.5*laplace_loss)
        return overall_loss, semantic_loss, laplace_loss

    def _yolact_loss(self, semantic_out, proto_out, coef_outputs, labels):
        coef_outputs = [tf.cast(i, tf.float32) for i in coef_outputs]
        levels = range(len(coef_outputs))
        pred_mask_coef_list = []
        for level in levels:
            pred_mask_coef_at_level = coef_outputs[level]
            bs, _, _, _, = pred_mask_coef_at_level.get_shape().as_list()
            if self.config.use_multi_scale_proto == 2:
                pred_mask_coef_at_level = tf.reshape(pred_mask_coef_at_level, [bs, -1, 12 * 12 * 4])
            else:
                pred_mask_coef_at_level = tf.reshape(pred_mask_coef_at_level, [bs, -1, 32])
            pred_mask_coef_list.append(pred_mask_coef_at_level)

        batch_pred_mask_coef = tf.concat(pred_mask_coef_list, axis=1)
        batch_pred_proto = proto_out
        batch_pred_segment = semantic_out

        batch_gt_instance_masks = labels['instance_masks']
        batch_gt_semantic_masks = labels['semantic_masks']
        batch_anchors_match_gt_indices = labels['anchors_match_gt_indices']
        batch_gt_boxes = labels['groundtruth_data'][:, :, :4]
        batch_gt_classes = labels['groundtruth_data'][:, :, 6]
        batch_num_positives_sum = labels['mean_num_positives']

        instance_mask_losses = 0
        semantic_mask_losses = 0.
        semantic_single_losses = 0
        laplace_loss = 0

        for idx in range(bs):
            pred_mask_coef = batch_pred_mask_coef[idx]
            pred_proto = batch_pred_proto[idx]
            pred_segment = batch_pred_segment[idx]
            anchors_match_gt_indices = batch_anchors_match_gt_indices[idx]
            gt_instance_masks = batch_gt_instance_masks[idx]
            gt_semantic_masks = batch_gt_semantic_masks[idx]
            gt_boxes = batch_gt_boxes[idx]
            gt_classes = batch_gt_classes[idx]
            num_positives_sum = batch_num_positives_sum[idx] + 1.0

            instance_mask_loss_per_image = self._instance_mask_loss(pred_proto, pred_mask_coef, gt_instance_masks,
                                                                    gt_boxes,
                                                                    anchors_match_gt_indices, num_positives_sum,
                                                                    self.config.use_multi_scale_proto,
                                                                    self.config.use_crop_loss)
            instance_mask_losses += instance_mask_loss_per_image

            semantic_mask_loss_per_image, semantic_single_loss_per_image, laplace_loss_per_image\
                = self._semantic_segmentation_with_laplace_loss(pred_segment, gt_semantic_masks)
            semantic_mask_losses += semantic_mask_loss_per_image
            semantic_single_losses += semantic_single_loss_per_image
            laplace_loss += laplace_loss_per_image

        instance_mask_losses = instance_mask_losses / bs
        semantic_mask_losses = semantic_mask_losses / bs
        semantic_single_losses = semantic_single_losses / bs
        laplace_loss = laplace_loss / bs
        return instance_mask_losses, semantic_mask_losses, semantic_single_losses, laplace_loss

    def _detection_loss(self, cls_outputs, box_outputs, labels, loss_vals,
                        semantic_out=None, proto_out=None, coef_outputs=None):
        """Computes total detection loss.

        Computes total detection loss including box and class loss from all levels.
        Args:
          cls_outputs: an OrderDict with keys representing levels and values
            representing logits in [batch_size, height, width, num_anchors].
          box_outputs: an OrderDict with keys representing levels and values
            representing box regression targets in [batch_size, height, width,
            num_anchors * 4].
          labels: the dictionary that returned from dataloader that includes
            groundtruth targets.
          loss_vals: A dict of loss values.

        Returns:
          total_loss: an integer tensor representing total loss reducing from
            class and box losses from all levels.
          cls_loss: an integer tensor representing total class loss.
          box_loss: an integer tensor representing total box regression loss.
          box_iou_loss: an integer tensor representing total box iou loss.
        """
        # convert to float32 for loss computing.
        cls_outputs = [tf.cast(i, tf.float32) for i in cls_outputs]
        box_outputs = [tf.cast(i, tf.float32) for i in box_outputs]
        coef_outputs = [tf.cast(i, tf.float32) for i in coef_outputs]
        semantic_out = tf.cast(semantic_out, tf.float32)
        proto_out = tf.cast(proto_out, tf.float32)

        # Sum all positives in a batch for normalization and avoid zero
        # num_positives_sum, which would lead to inf loss during training
        num_positives_sum = tf.reduce_sum(labels['mean_num_positives']) + 1.0
        levels = range(len(cls_outputs))
        cls_losses = []
        box_losses = []
        for level in levels:
            # Onehot encoding for classification labels.
            cls_targets_at_level = tf.one_hot(labels['cls_targets_%d' % (level + 3)],
                                              self.config.num_classes)

            if self.config.data_format == 'channels_first':
                bs, _, width, height, _ = cls_targets_at_level.get_shape().as_list()
                cls_targets_at_level = tf.reshape(cls_targets_at_level,
                                                  [bs, -1, width, height])
            else:
                bs, width, height, _, _ = cls_targets_at_level.get_shape().as_list()
                cls_targets_at_level = tf.reshape(cls_targets_at_level,
                                                  [bs, width, height, -1])
            box_targets_at_level = labels['box_targets_%d' % (level + 3)]

            class_loss_layer = self.loss.get('class_loss', None)
            if class_loss_layer:
                cls_loss = class_loss_layer([num_positives_sum, cls_targets_at_level],
                                            cls_outputs[level])

                if self.config.data_format == 'channels_first':
                    cls_loss = tf.reshape(
                        cls_loss, [bs, -1, width, height, self.config.num_classes])
                else:
                    cls_loss = tf.reshape(
                        cls_loss, [bs, width, height, -1, self.config.num_classes])
                cls_loss *= tf.cast(
                    tf.expand_dims(
                        tf.not_equal(labels['cls_targets_%d' % (level + 3)], -2), -1),
                    tf.float32)
                cls_losses.append(tf.reduce_sum(cls_loss))

            if self.config.box_loss_weight and self.loss.get('box_loss', None):
                box_loss_layer = self.loss['box_loss']
                box_losses.append(
                    box_loss_layer([num_positives_sum, box_targets_at_level],
                                   box_outputs[level]))

        if self.config.iou_loss_type:
            box_outputs = tf.concat([tf.reshape(v, [-1, 4]) for v in box_outputs],
                                    axis=0)
            box_targets = tf.concat([
                tf.reshape(labels['box_targets_%d' % (level + 3)], [-1, 4])
                for level in levels
            ],
                axis=0)
            box_iou_loss_layer = self.loss['box_iou_loss']
            box_iou_loss = box_iou_loss_layer([num_positives_sum, box_targets],
                                              box_outputs)
            loss_vals['box_iou_loss'] = box_iou_loss
        else:
            box_iou_loss = 0

        instance_mask_loss = 0
        semantic_mask_loss = 0
        semantic_single_loss = 0
        laplace_loss = 0
        if self.config.include_mask:
            instance_mask_loss, semantic_mask_loss, semantic_single_loss, laplace_loss\
                = self._yolact_loss(semantic_out, proto_out, coef_outputs, labels)
            instance_mask_loss = tf.squeeze(instance_mask_loss)
        #semantic_mask_loss = tf.cast(semantic_mask_loss, dtype=tf.float32)
        #semantic_single_loss = tf.cast(semantic_single_loss, dtype=tf.float32)
        #laplace_loss = tf.cast(laplace_loss, dtype=tf.float32)
        cls_loss = tf.add_n(cls_losses) if cls_losses else 0
        box_loss = tf.add_n(box_losses) if box_losses else 0
        total_loss = (
                cls_loss + self.config.box_loss_weight * box_loss +
                self.config.iou_loss_weight * box_iou_loss +
                instance_mask_loss + semantic_mask_loss)
        loss_vals['det_loss'] = total_loss
        loss_vals['cls_loss'] = cls_loss
        loss_vals['box_loss'] = box_loss
        loss_vals['instance_mask_loss'] = instance_mask_loss
        loss_vals['semantic_mask_loss'] = semantic_mask_loss
        loss_vals['semantic_single_loss'] = semantic_single_loss
        loss_vals['laplace_loss'] = laplace_loss

        return total_loss, cls_loss, box_loss, box_iou_loss, instance_mask_loss, semantic_mask_loss, semantic_single_loss, laplace_loss

    def train_step(self, data):
        """Train step.

        Args:
          data: Tuple of (images, labels). Image tensor with shape [batch_size,
            height, width, 3]. The height and width are fixed and equal.Input labels
            in a dictionary. The labels include class targets and box targets which
            are dense label maps. The labels are generated from get_input_fn
            function in data/dataloader.py.

        Returns:
          A dict record loss info.
        """
        images, labels = data
        with tf.GradientTape() as tape:
            if self.config.include_mask:
                cls_outputs, box_outputs, semantic_out, proto_out, coef_outputs = self(images, training=True)
            elif len(self.config.heads) == 2:
                cls_outputs, box_outputs, seg_outputs = self(images, training=True)
            elif 'object_detection' in self.config.heads:
                cls_outputs, box_outputs, _, _, _ = self(images, training=True)
            elif 'segmentation' in self.config.heads:
                seg_outputs = self(images, training=True)
            reg_l2loss = self._reg_l2_loss(self.config.weight_decay)
            total_loss = reg_l2loss
            loss_vals = {}
            if self.config.include_mask:
                det_loss = (
                    self._detection_loss(cls_outputs, box_outputs, labels, loss_vals, semantic_out, proto_out,
                                         coef_outputs))
                total_loss += det_loss
            elif 'object_detection' in self.config.heads:
                det_loss = (
                    self._detection_loss(cls_outputs, box_outputs, labels, loss_vals))
                total_loss += det_loss
            if 'segmentation' in self.config.heads:
                seg_loss_layer = self.loss['seg_loss']
                seg_loss = seg_loss_layer(seg_outputs, labels['image_masks'])
                total_loss += seg_loss
                loss_vals['seg_loss'] = seg_loss
            if isinstance(self.optimizer,
                          tf.keras.mixed_precision.experimental.LossScaleOptimizer):
                scaled_loss = self.optimizer.get_scaled_loss(total_loss)
            else:
                scaled_loss = total_loss
        loss_vals['loss'] = total_loss
        trainable_vars = self._freeze_vars()
        scaled_gradients = tape.gradient(scaled_loss, trainable_vars)
        if isinstance(self.optimizer,
                      tf.keras.mixed_precision.experimental.LossScaleOptimizer):
            gradients = self.optimizer.get_unscaled_gradients(scaled_gradients)
        else:
            gradients = scaled_gradients
        if self.config.clip_gradients_norm > 0:
            gradients, gnorm = tf.clip_by_global_norm(gradients,
                                                      self.config.clip_gradients_norm)
            loss_vals['gnorm'] = gnorm
        self.optimizer.apply_gradients(zip(gradients, trainable_vars))
        return loss_vals

    def test_step(self, data):
        """Test step.

        Args:
          data: Tuple of (images, labels). Image tensor with shape [batch_size,
            height, width, 3]. The height and width are fixed and equal.Input labels
            in a dictionary. The labels include class targets and box targets which
            are dense label maps. The labels are generated from get_input_fn
            function in data/dataloader.py.

        Returns:
          A dict record loss info.
        """
        images, labels = data
        if self.config.include_mask:
            cls_outputs, box_outputs, semantic_out, proto_out, coef_outputs = self(images, training=True)
        elif len(self.config.heads) == 2:
            cls_outputs, box_outputs, seg_outputs = self(images, training=True)
        elif 'object_detection' in self.config.heads:
            cls_outputs, box_outputs = self(images, training=True)
        elif 'segmentation' in self.config.heads:
            seg_outputs = self(images, training=True)
        reg_l2loss = self._reg_l2_loss(self.config.weight_decay)
        total_loss = reg_l2loss
        loss_vals = {}

        if self.config.include_mask:
            det_loss = (
                self._detection_loss(cls_outputs, box_outputs, labels, loss_vals, semantic_out, proto_out,
                                     coef_outputs))
            total_loss += det_loss
        elif 'object_detection' in self.config.heads:
            det_loss = (
                self._detection_loss(cls_outputs, box_outputs, labels, loss_vals))
            total_loss += det_loss
        if 'segmentation' in self.config.heads:
            seg_loss_layer = self.loss['seg_loss']
            seg_loss = seg_loss_layer(seg_outputs, labels['image_masks'])
            total_loss += seg_loss
            loss_vals['seg_loss'] = seg_loss
        loss_vals['loss'] = total_loss
        return loss_vals
