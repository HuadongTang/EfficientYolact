# Copyright 2020 Google Research. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Common keras utils."""
from typing import Text
import tensorflow as tf

import utils


def build_batch_norm(is_training_bn: bool,
                     beta_initializer: Text = 'zeros',
                     gamma_initializer: Text = 'ones',
                     data_format: Text = 'channels_last',
                     momentum: float = 0.99,
                     epsilon: float = 1e-3,
                     strategy: Text = None,
                     name: Text = 'tpu_batch_normalization'):
    """Build a batch normalization layer.

    Args:
      is_training_bn: `bool` for whether the model is training.
      beta_initializer: `str`, beta initializer.
      gamma_initializer: `str`, gamma initializer.
      data_format: `str` either "channels_first" for `[batch, channels, height,
        width]` or "channels_last for `[batch, height, width, channels]`.
      momentum: `float`, momentume of batch norm.
      epsilon: `float`, small value for numerical stability.
      strategy: `str`, whether to use tpu, horovod or other version of batch norm.
      name: the name of the batch normalization layer

    Returns:
      A normalized `Tensor` with the same `data_format`.
    """
    axis = 1 if data_format == 'channels_first' else -1
    batch_norm_class = utils.batch_norm_class(is_training_bn, strategy)

    bn_layer = batch_norm_class(
        axis=axis,
        momentum=momentum,
        epsilon=epsilon,
        center=True,
        scale=True,
        beta_initializer=beta_initializer,
        gamma_initializer=gamma_initializer,
        name=name)

    return bn_layer

def sanitize_coordinates(_x1, _x2, img_size):
    img_size = tf.cast(img_size, dtype=tf.float32)
    padding = ((1.0 - (_x2 - _x1)) / 4.0) * img_size
    _x1 = _x1 * img_size
    _x2 = _x2 * img_size
    x1 = tf.maximum(_x1 - padding, 0.)
    x2 = tf.minimum(_x2 + padding, img_size)
    return x1, x2


# crop the prediction of mask so as to calculate the linear combination mask loss
def crop(pred, boxes_norm):
    pred_shape = tf.shape(pred)

    y1, y2 = sanitize_coordinates(boxes_norm[:, 0], boxes_norm[:, 2], pred_shape[1])
    x1, x2 = sanitize_coordinates(boxes_norm[:, 1], boxes_norm[:, 3], pred_shape[2])

    w = tf.cast(tf.range(pred_shape[2]), tf.float32)
    h = tf.expand_dims(tf.cast(tf.range(pred_shape[1]), tf.float32), axis=-1)

    cols = tf.broadcast_to(w, pred_shape)
    rows = tf.broadcast_to(h, pred_shape)

    ymin = tf.broadcast_to(tf.reshape(y1, [-1, 1, 1]), pred_shape)
    xmin = tf.broadcast_to(tf.reshape(x1, [-1, 1, 1]), pred_shape)
    ymax = tf.broadcast_to(tf.reshape(y2, [-1, 1, 1]), pred_shape)
    xmax = tf.broadcast_to(tf.reshape(x2, [-1, 1, 1]), pred_shape)

    mask_left = (cols >= xmin)
    mask_right = (cols <= xmax)
    mask_bottom = (rows >= ymin)
    mask_top = (rows <= ymax)

    crop_mask = tf.math.logical_and(tf.math.logical_and(mask_left, mask_right),
                                    tf.math.logical_and(mask_bottom, mask_top))
    crop_mask = tf.cast(crop_mask, tf.float32)
    # tf.print('crop', tf.shape(crop_mask))

    out = pred * crop_mask

    return out
