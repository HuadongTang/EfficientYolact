# Copyright 2020 Google Research. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Eval libraries."""
from absl import app
from absl import flags
from absl import logging
import tensorflow as tf
import os

os.environ["TF_FORCE_GPU_ALLOW_GROWTH"] = "true"

import coco_metric
import coco_mask_metric
import dataloader
import hparams_config
import utils

from keras import anchors
from keras import efficientdet_keras
from keras import label_util
from keras import postprocess
from keras import wbf

flags.DEFINE_enum('strategy', 'gpus', ['tpu', 'gpus', ''],
                  'Training: gpus for multi-gpu, if None, use TF default.')
flags.DEFINE_string('val_file_pattern',
                    '/home/hd8t/chaofan.du/instance/coco/coco8_include_seg_tfrecord/val*.tfrecord',
                    'Glob for eval tfrecords, e.g. coco/val-*.tfrecord.')
flags.DEFINE_string(
    'val_json_file',
    'data/instances_coco_val2017_8classes.json',
    'Groudtruth file, e.g. annotations/instances_val2017.json.')

flags.DEFINE_string('model_name', 'efficientdet-d2', 'Model name to use.')
flags.DEFINE_string('model_h5_path',
                    '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/out/i2-keras-coco8-snpe-semantic-resize-conv/model.h5',
                    'Location of the checkpoint to run.')
flags.DEFINE_string('model_dir',
                    None,
                    'Location of the checkpoint to run.')
flags.DEFINE_integer('batch_size', 12, 'Batch size.')
flags.DEFINE_integer('eval_samples', 5000, 'he number of samples for evaluation')
flags.DEFINE_string('hparams',
                    'label_map=coco_8, num_classes=8,moving_average_decay=0,include_mask=True,use_se=False,act_type=relu6,fpn_weight_method=sum,',
                    'Comma separated k=v pairs or a yaml file')  # act_type=relu6,fpn_weight_method=sum,use_se=False,iou_loss_type=ciou
flags.DEFINE_boolean('enable_tta', False,
                     'Use test time augmentation (slower, but more accurate).')
FLAGS = flags.FLAGS


def de_normalize_image(_image):
    """Normalize the image to zero mean and unit variance."""
    # The image normalization is identical to Cloud TPU ResNet.

    scale = tf.constant([0.229, 0.224, 0.225])
    scale = tf.expand_dims(scale, axis=0)
    scale = tf.expand_dims(scale, axis=0)

    _image *= scale

    offset = tf.constant([0.485, 0.456, 0.406])
    offset = tf.expand_dims(offset, axis=0)
    offset = tf.expand_dims(offset, axis=0)

    _image += offset

    _image *= 255

    return tf.cast(_image, dtype=tf.uint8)


def do_eval(evaluator, eval_mask_metric, include_mask=False):
    # compute the final eval results.
    metric_values = evaluator.result()
    metric_dict = {}
    for i, metric_value in enumerate(metric_values):
        metric_dict[evaluator.metric_names[i]] = metric_value
    print(metric_dict)

    if include_mask:
        # compute the final eval results.
        mask_metric_values = eval_mask_metric.result()
        mask_metric_dict = {}
        for i, mask_metric_value in enumerate(mask_metric_values):
            mask_metric_dict[eval_mask_metric.mask_metric_names[i]] = mask_metric_value
        print(mask_metric_dict)


def main(_):
    config = hparams_config.get_efficientdet_config(FLAGS.model_name)
    config.override(FLAGS.hparams)
    config.batch_size = FLAGS.batch_size
    config.val_json_file = FLAGS.val_json_file
    config.nms_configs.max_nms_inputs = anchors.MAX_DETECTION_POINTS
    base_height, base_width = utils.parse_image_size(config['image_size'])

    if FLAGS.strategy == 'tpu':
        tpu_cluster_resolver = tf.distribute.cluster_resolver.TPUClusterResolver(
            FLAGS.tpu, zone=FLAGS.tpu_zone, project=FLAGS.gcp_project)
        tf.config.experimental_connect_to_cluster(tpu_cluster_resolver)
        tf.tpu.experimental.initialize_tpu_system(tpu_cluster_resolver)
        ds_strategy = tf.distribute.TPUStrategy(tpu_cluster_resolver)
        logging.info('All devices: %s', tf.config.list_logical_devices('TPU'))
    elif FLAGS.strategy == 'gpus':
        ds_strategy = tf.distribute.MirroredStrategy()
        logging.info('All devices: %s', tf.config.list_physical_devices('GPU'))
    else:
        if tf.config.list_physical_devices('GPU'):
            ds_strategy = tf.distribute.OneDeviceStrategy('device:GPU:0')
        else:
            ds_strategy = tf.distribute.OneDeviceStrategy('device:CPU:0')

    # in format (height, width, flip)
    augmentations = []
    if FLAGS.enable_tta:
        for size_offset in (0, 128, 256):
            for flip in (False, True):
                augmentations.append(
                    (base_height + size_offset, base_width + size_offset, flip))
    else:
        augmentations.append((base_height, base_width, False))

    with ds_strategy.scope():
        # Network
        model = efficientdet_keras.EfficientDetNet(config=config)
        model.build((config.batch_size, base_height, base_width, 3))
        if FLAGS.model_h5_path:
            model.load_weights(FLAGS.model_h5_path, by_name=True, skip_mismatch=True)
        else:
            model.load_weights(tf.train.latest_checkpoint(FLAGS.model_dir))

        evaluator = coco_metric.EvaluationMetric(filename=config.val_json_file)
        evaluator_mask = coco_mask_metric.EvaluationMaskMetric(filename=config.val_json_file)

        first_loop = True
        for height, width, flip in augmentations:
            config.image_size = (height, width)
            # dataset
            ds = dataloader.InputReader(
                FLAGS.val_file_pattern,
                is_training=False,
                use_fake_data=False,
                max_instances_per_image=config.max_instances_per_image)(
                config)
            if FLAGS.eval_samples:
                ds = ds.take(FLAGS.eval_samples // config.batch_size)

            # create the function once per augmentation, since it closes over the
            # value of config, which gets updated with the new image size
            @tf.function
            def f(images, labels):
                if config.include_mask:
                    print('include_mask ')
                    cls_outputs, box_outputs, semantic_out, proto_out, coef_outputs = model(images, training=False)
                    ori_imgs_height = labels['ori_image_height']
                    ori_imgs_width = labels['ori_image_width']
                else:
                    cls_outputs, box_outputs, semantic_out, proto_out, coef_outputs = model(images, training=False)
                    ori_imgs_height = None
                    ori_imgs_width = None
                    proto_out = None
                    coef_outputs = None

                return postprocess.generate_detections(config, cls_outputs, box_outputs,
                                                       labels['image_scales'],
                                                       labels['source_ids'], flip,
                                                       ori_imgs_height=ori_imgs_height,
                                                       ori_imgs_width=ori_imgs_width,
                                                       proto_out=proto_out,
                                                       coef_outputs=coef_outputs,
                                                       mask_threshold_after_sigmod=0.5
                                                       )

            # inference
            step = 1
            for images, labels in ds:
                print('run inference step ', step)
                step += 1
                if flip:
                    images = tf.image.flip_left_right(images)
                detections, detections_mask = f(images, labels)
                evaluator.update_state(
                    labels['groundtruth_data'].numpy(),
                    postprocess.transform_detections(detections).numpy())
                if config.include_mask:
                    detections_mask_np = []
                    for i in range(config.batch_size):
                        detections_mask_np.append(detections_mask[i].numpy())
                    evaluator_mask.update_op(postprocess.transform_detections(detections).numpy(),
                                             detections_mask_np)

    # compute the final eval results.
    if evaluator:
        metrics = evaluator.result()
        metric_dict = {}
        for i, name in enumerate(evaluator.metric_names):
            metric_dict[name] = metrics[i]

        label_map = label_util.get_label_map(config.label_map)
        if label_map:
            for i, cid in enumerate(sorted(label_map.keys())):
                name = 'AP_/%s' % label_map[cid]
                metric_dict[name] = metrics[i + len(evaluator.metric_names)]
        print(metric_dict)

    if evaluator_mask:
        metrics_mask = evaluator_mask.result()
        metric_mask_dict = {}
        for i, name in enumerate(evaluator_mask.mask_metric_names):
            metric_mask_dict[name] = metrics_mask[i]

        label_map = label_util.get_label_map(config.label_map)
        if label_map:
            for i, cid in enumerate(sorted(label_map.keys())):
                name = 'mask_AP_/%s' % label_map[cid]
                metric_mask_dict[name] = metrics_mask[i + len(evaluator_mask.mask_metric_names)]
        print(metric_mask_dict)

    # # dataset
    # ds = dataloader.InputReader(
    #     FLAGS.val_file_pattern,
    #     is_training=False,
    #     use_fake_data=False,
    #     max_instances_per_image=config.max_instances_per_image)(
    #     config)
    #
    # # Network
    # model = efficientdet_keras.EfficientDetNet(config=config)
    # model.build((config.batch_size, config.image_size, config.image_size, 3))
    # if FLAGS.model_h5_path:
    #     model.load_weights(FLAGS.model_h5_path, by_name=True, skip_mismatch=True)
    # else:
    #     model.load_weights(tf.train.latest_checkpoint(FLAGS.model_dir))
    #
    # evaluator = coco_metric.EvaluationMetric(filename=config.val_json_file)
    # eval_mask_metric = coco_mask_metric.EvaluationMaskMetric(filename=config.val_json_file)
    #
    # # compute stats for all batches.
    # step = 1
    # for images, labels in ds:
    #
    #     # if True:
    #     #     from PIL import Image
    #     #     import numpy as np
    #     #     instance_masks = labels['instance_masks']
    #     #     semantic_masks = labels['semantic_masks']
    #     #     for i in range(8):
    #     #
    #     #         image_np = de_normalize_image(images[i]).numpy()
    #     #         output_image_path = '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/s_image_%d.png' % (
    #     #             i)
    #     #         Image.fromarray(image_np).save(output_image_path)
    #     #
    #     #         semantic_mask_np = np.squeeze(semantic_masks[i].numpy().astype(np.uint8))
    #     #         output_image_path = '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/s_mask_%d.png'%(i)
    #     #         Image.fromarray(semantic_mask_np).save(output_image_path)
    #     #
    #     #         print('writing annotated image to ', output_image_path)
    #
    #     if FLAGS.eval_samples <= FLAGS.batch_size * step:
    #         break
    #     print('cur step ', step)
    #     step += 1
    #
    #
    #     config.nms_configs.max_nms_inputs = anchors.MAX_DETECTION_POINTS
    #
    #     if config.include_mask:
    #         cls_outputs, box_outputs, semantic_out,  proto_out, coef_outputs = model(images, training=False)
    #         ori_imgs_height = labels['ori_image_height']
    #         ori_imgs_width = labels['ori_image_width']
    #     else:
    #         cls_outputs, box_outputs, semantic_out,  proto_out, coef_outputs = model(images, training=False)
    #         ori_imgs_height = None
    #         ori_imgs_width = None
    #         proto_out = None
    #         coef_outputs = None
    #     detections, detections_mask = postprocess.generate_detections(config, cls_outputs,
    #                                                  box_outputs,
    #                                                  labels['image_scales'],
    #                                                  labels['source_ids'], False,
    #                                                  ori_imgs_height=ori_imgs_height,
    #                                                  ori_imgs_width=ori_imgs_width,
    #                                                  proto_out=proto_out,
    #                                                  coef_outputs=coef_outputs,
    #                                                  mask_threshold_after_sigmod=0.5)
    #
    #     if FLAGS.enable_tta:
    #         images_flipped = tf.image.flip_left_right(images)
    #         cls_outputs_flipped, box_outputs_flipped = model(
    #             images_flipped, training=False)
    #         detections_flipped, _ = postprocess.generate_detections(
    #             config, cls_outputs_flipped, box_outputs_flipped,
    #             labels['image_scales'], labels['source_ids'], True)
    #
    #         for d, df in zip(detections, detections_flipped):
    #             combined_detections = wbf.ensemble_detections(config,
    #                                                           tf.concat([d, df], 0))
    #             combined_detections = tf.stack([combined_detections])
    #             evaluator.update_state(
    #                 labels['groundtruth_data'].numpy(),
    #                 postprocess.transform_detections(combined_detections).numpy())
    #     else:
    #         evaluator.update_state(
    #             labels['groundtruth_data'].numpy(),
    #             postprocess.transform_detections(detections).numpy())
    #         if config.include_mask:
    #             detections_mask_np = []
    #             for i in range(config.batch_size):
    #                 detections_mask_np.append(detections_mask[i].numpy())
    #             eval_mask_metric.update_op(postprocess.transform_detections(detections).numpy(),
    #                                        detections_mask_np)
    #
    #     # if (step*FLAGS.batch_size) % 200 == 0:
    #     #     do_eval(evaluator, eval_mask_metric, config.include_mask)
    #
    #
    # do_eval(evaluator, eval_mask_metric, config.include_mask)


if __name__ == '__main__':
    flags.mark_flag_as_required('val_file_pattern')
    flags.mark_flag_as_required('val_json_file')
    logging.set_verbosity(logging.INFO)
    app.run(main)
