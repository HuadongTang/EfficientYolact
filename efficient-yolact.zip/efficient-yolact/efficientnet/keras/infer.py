# Copyright 2020 Google Research. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""A simple example on how to use keras model for inference."""
import os
from absl import app
from absl import flags
from absl import logging
import numpy as np
from PIL import Image
import tensorflow as tf

import hparams_config
import inference
from keras import efficientdet_keras
from keras import label_util

flags.DEFINE_string('image_path', 'testdata/589ba51c2bbf4.image.jpg', 'Location of test image.')
flags.DEFINE_string('image_path_pattern',
                    '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/testdata/*.jpg',
                    'Location of test image.')
flags.DEFINE_string('output_dir', '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/testdata_out',
                    'Directory of annotated output images.')
flags.DEFINE_string('model_dir',
                    '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/out/i2-keras-coco8-snpe',
                    'Location of the checkpoint to run.')
flags.DEFINE_string('h5_model_path',
                    '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/out/i2-keras-coco8-snpe-semantic-resize-conv/model.h5',
                    'Location of the checkpoint to run.')
flags.DEFINE_string('model_name', 'efficientdet-d2', 'Model name to use.')
flags.DEFINE_float('mask_threshold_after_sigmoid', 0.5, 'mask_threshold_after_sigmod.')
flags.DEFINE_string('hparams',
                    'num_classes=8,moving_average_decay=0,mixed_precision=False,use_se=False,act_type=relu6,fpn_weight_method=sum,include_mask=True',
                    'Comma separated k=v pairs or a yaml file')
flags.DEFINE_bool('debug', False, 'If true, run function in eager for debug.')
FLAGS = flags.FLAGS


def main(_):
    # pylint: disable=line-too-long
    # Prepare images and checkpoints: please run these commands in shell.
    # !mkdir tmp
    # !wget https://user-images.githubusercontent.com/11736571/77320690-099af300-6d37-11ea-9d86-24f14dc2d540.png -O tmp/img.png
    # !wget https://storage.googleapis.com/cloud-tpu-checkpoints/efficientdet/coco/efficientdet-d0.tar.gz -O tmp/efficientdet-d0.tar.gz
    # !tar zxf tmp/efficientdet-d0.tar.gz -C tmp
    # imgs = [np.array(Image.open(FLAGS.image_path))]

    if not tf.io.gfile.exists(FLAGS.output_dir):
        tf.io.gfile.makedirs(FLAGS.output_dir)

    imgs = []
    file_names = []
    for f in tf.io.gfile.glob(FLAGS.image_path_pattern):
        file_names.append(f)
        image = Image.open(f)
        imgs.append(np.array(image))

    # Create model config.
    # config = hparams_config.get_efficientdet_config('efficientdet-d2')
    # config.is_training_bn = False
    # # config.image_size = '1920x1280'
    # config.nms_configs.score_thresh = 0.4
    # config.nms_configs.max_output_size = 100
    # config.override(FLAGS.hparams)

    config = hparams_config.get_efficientdet_config(FLAGS.model_name)
    config.nms_configs.score_thresh = 0.4
    config.nms_configs.max_output_size = 100
    config.override(FLAGS.hparams)

    # # Use 'mixed_float16' if running on GPUs.
    # policy = tf.keras.mixed_precision.experimental.Policy('float32')
    # tf.keras.mixed_precision.experimental.set_policy(policy)
    # tf.config.experimental_run_functions_eagerly(FLAGS.debug)

    # Create and run the model.
    model = efficientdet_keras.EfficientDetModel(config=config)
    model.build((1, None, None, 3))

    if FLAGS.h5_model_path:
        model.load_weights(FLAGS.h5_model_path, by_name=True, skip_mismatch=True)
        print('load h5 model ', FLAGS.h5_model_path)
    else:
        model.load_weights(tf.train.latest_checkpoint(FLAGS.model_dir))
        print('load ckpt model ', FLAGS.model_dir)

    # model.summary()

    @tf.function
    def f(imgs):
        return model(imgs, training=False, post_mode='global',
                     mask_threshold_after_sigmoid=FLAGS.mask_threshold_after_sigmoid)

    # Visualize results.
    for i, img in enumerate(imgs):
        boxes, scores, classes, valid_len, instance_masks, semantic_masks = f(np.expand_dims(img, axis=0))
        length = valid_len[0]
        img = inference.visualize_image(
            img,
            boxes[0].numpy()[:length],
            classes[0].numpy().astype(np.int)[:length],
            scores[0].numpy()[:length],
            label_map=label_util.get_label_map('coco_8'),
            min_score_thresh=config.nms_configs.score_thresh,
            max_boxes_to_draw=config.nms_configs.max_output_size,
            instance_masks=instance_masks[0].numpy()[:length])
        base_name = os.path.basename(file_names[i])
        output_image_path = os.path.join(FLAGS.output_dir, base_name)
        Image.fromarray(img).save(output_image_path)
        print('writing annotated image to ', output_image_path)

        output_semantic_mask_path = os.path.join(FLAGS.output_dir, 'semantic_mask_' + base_name.split('.')[0] + '.png')
        Image.fromarray(semantic_masks[0].numpy()).save(output_semantic_mask_path)
        print('writing semantic mask image to ', output_semantic_mask_path)


if __name__ == '__main__':
    flags.mark_flag_as_required('image_path')
    flags.mark_flag_as_required('output_dir')
    flags.mark_flag_as_required('model_dir')
    logging.set_verbosity(logging.WARNING)
    app.run(main)
