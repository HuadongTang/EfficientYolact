# Copyright 2020 Google Research. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""The main training script."""
import os

os.environ["TF_FORCE_GPU_ALLOW_GROWTH"] = "true"

from absl import app
from absl import flags
from absl import logging
import tensorflow as tf

import dataloader
import hparams_config
import utils
from keras import train_lib
import h5py

flags.DEFINE_string('model_dir',
                    '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/out/i2-keras-coco8-snpe-semantic-resize-conv',
                    'Location of model_dir')
flags.DEFINE_string('ckpt_path',
                    '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/out/i2-keras-coco8-snpe',
                    'Location of model_dir')
flags.DEFINE_string('input_h5_path',
                    '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/out/i2-keras-coco8-snpe-semantic-resize-conv/model.h5',
                    'Location of model_dir')
flags.DEFINE_string('out_h5_path',
                    None,
                    # '/home/samsung/alpha/xsong/tf_ws/automl-master-0731/efficientdet/out/i2-keras-coco8-snpe/model.h5',
                    'Location of model_dir')
# flags.DEFINE_string('ckpt_path', 'download_models/efficientdet-d2', 'Location of model_dir')


flags.DEFINE_string(
    'hparams',
    # 'moving_average_decay=0,learning_rate=0.008,',
    'num_classes=8,moving_average_decay=0,mixed_precision=False,learning_rate=0.001,use_se=False,act_type=relu6,fpn_weight_method=sum,include_mask=True,',
    'Comma separated k=v pairs of hyperparameters or a module'
    ' containing attributes to use as hyperparameters.')

flags.DEFINE_integer('batch_size', 1, 'training batch size')

flags.DEFINE_string('model_name', 'efficientdet-d2', 'Model name.')

FLAGS = flags.FLAGS


def check_h5():
    f = h5py.File(FLAGS.input_h5_path)
    for key in f.keys():
        for subkey in f[key]:
            print(subkey)
            print(f[key][subkey].shape)


def main(_):
    # check_h5()
    # Parse and override hparams
    config = hparams_config.get_detection_config(FLAGS.model_name)
    config.override(FLAGS.hparams)

    # Parse image size in case it is in string format.
    config.image_size = utils.parse_image_size(config.image_size)

    params = dict(
        config.as_dict(),
        model_name=FLAGS.model_name,

        model_dir=FLAGS.model_dir,

        batch_size=FLAGS.batch_size)

    model = train_lib.EfficientDetNetTrain(params['model_name'], config)
    height, width = utils.parse_image_size(params['image_size'])
    model.build((params['batch_size'], height, width, 3))

    if FLAGS.input_h5_path:
        model.load_weights(FLAGS.input_h5_path, by_name=True, skip_mismatch=True)
    else:
        ckpt_path = tf.train.latest_checkpoint(FLAGS.ckpt_path)

        if ckpt_path:
            model.load_weights(ckpt_path)
            print('load model weights ', ckpt_path)

    if FLAGS.out_h5_path:
        model.save_weights(FLAGS.out_h5_path)
    else:
        model.save_weights(os.path.join(FLAGS.model_dir, 'model'))


if __name__ == '__main__':
    logging.set_verbosity(logging.WARNING)
    app.run(main)
