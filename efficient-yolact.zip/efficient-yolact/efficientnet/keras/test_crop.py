import tensorflow as tf
from keras import utils_keras

a = tf.random.normal([1, 192, 192])

box = tf.constant([[0.6, 0.5, 0.8, 0.6]])

b = utils_keras.crop(a, box)

print(b)
