# Copyright 2020 Google Research. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""COCO-style evaluation metrics.

Implements the interface of COCO API and metric_fn in tf.TPUEstimator.

COCO API: github.com/cocodataset/cocoapi/
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import json
import gc
import os
from absl import flags
from absl import logging

import numpy as np
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from pycocotools import mask

import tensorflow.compat.v1 as tf

FLAGS = flags.FLAGS


class EvaluationMaskMetric():
    """COCO evaluation metric class."""

    def __init__(self, filename=None, testdev_dir=None):
        """Constructs COCO evaluation class.

        The class provides the interface to metrics_fn in TPUEstimator. The
        _update_op() takes detections from each image and push them to
        self.detections. The _evaluate() loads a JSON file in COCO annotation format
        as the groundtruth and runs COCO evaluation.

        Args:
          filename: Ground truth JSON file name. If filename is None, use
            groundtruth data passed from the dataloader for evaluation. filename is
            ignored if testdev_dir is not None.
          testdev_dir: folder name for testdev data. If None, run eval without
            groundtruth, and filename will be ignored.
        """
        if filename:
            self.coco_gt = COCO(filename)
        self.filename = filename
        self.testdev_dir = testdev_dir

        self.mask_metric_names = ['mask_AP', 'mask_AP50', 'mask_AP75', 'mask_APs', 'mask_APm', 'mask_APl',
                                  'mask_ARmax1',
                                  'mask_ARmax10', 'mask_ARmax100', 'mask_ARs', 'mask_ARm', 'mask_ARl']

        self.detections = []
        self.masks = []
        self._reset()


    def _reset(self):
        """Reset COCO API object."""
        if self.filename is None:
            self.coco_gt = COCO()
        if self.detections:
            del self.detections

        self.detections = []
        self.dataset = {
            'images': [],
            'annotations': [],
            'categories': []
        }
        self.image_id = 1
        self.annotation_id = 1
        self.category_ids = []
        self.image_ids = []
        if self.masks:
            del self.masks
        self.masks = []


        gc.collect()
        self.metric_values = None
        self.out_json_file = os.path.join('out', 'masks_test-dev2017_test_results.json')
        if os.path.exists(self.out_json_file):
            os.remove(self.out_json_file)

    def _RleCompress(self, masks):
        """Compresses mask using Run-length encoding provided by pycocotools.

        Args:
          masks: uint8 numpy array of shape [mask_height, mask_width] with values in
          {0, 1}.

        Returns:
          A pycocotools Run-length encoding of the mask.
        """
        rle = mask.encode(np.asfortranarray(masks))
        rle['counts'] = rle['counts'].decode('ascii')  # json.dump doesn't like bytes strings
        return rle

    def result(self):
        """Return the metric values (and compute it if needed)."""
        if not self.metric_values:
            self.metric_values = self.evaluate()
        return self.metric_values


    def evaluate(self,):
        """Evaluates with detections from all images with COCO API.

        Returns:
          coco_metric: float numpy array with shape [12] representing the
            coco-style evaluation metrics.
        """
        if self.filename is None:
            self.coco_gt.dataset = self.dataset
            self.coco_gt.createIndex()

        seg_result_list = []
        for det, mask in zip(self.detections, self.masks):
            seg_result_list.append({
                'image_id': int(det[0]),
                'category_id': int(det[6]),
                'segmentation': self._RleCompress(mask),
                'score': float(np.around(det[5], decimals=3)),
            })
        # json.encoder.FLOAT_REPR = lambda o: format(o, '.3f')
        # output_path = self.out_json_file
        # logging.info('Writing output json file to: %s', output_path)
        # with tf.io.gfile.GFile(output_path, 'w') as fid:
        #     json.dump(seg_result_list, fid)

        # Run on validation dataset.

        coco_dt = self.coco_gt.loadRes(seg_result_list)
        # coco_dt = self.coco_gt.loadRes(self.out_json_file)
        coco_eval = COCOeval(self.coco_gt, coco_dt, iouType='segm')
        coco_eval.params.imgIds = self.image_ids
        coco_eval.evaluate()
        coco_eval.accumulate()
        coco_eval.summarize()
        coco_metrics = coco_eval.stats
        # clean self.detections after evaluation is done.
        # this makes sure the next evaluation will start with an empty list of
        # self.detections.
        self._reset()
        return np.array(coco_metrics, dtype=np.float32)

    def update_op(self, detections, pred_masks):
        """Update detection results and groundtruth data.

        Append detection results to self.detections to aggregate results from
        all validation set. The groundtruth_data is parsed and added into a
        dictionary with the same format as COCO dataset, which can be used for
        evaluation.

        Args:
         detections: Detection results in a tensor with each row representing
           [image_id, x, y, width, height, score, class].
         groundtruth_data: Groundtruth annotations in a tensor with each row
           representing [y1, x1, y2, x2, is_crowd, area, class].
        """
        for i in range(len(detections)):
            # Filter out detections with predicted class label = -1.
            indices = np.where(detections[i, :, -2] > 0.1)[0]
            # print(indices)

            valid_detection = detections[i, indices]
            if valid_detection.shape[0] == 0:
                continue

            # Append groundtruth annotations to create COCO dataset object.
            # Add images.
            image_id = valid_detection[0, 0]
            if image_id == -1:
                image_id = self.image_id
            valid_detection[:, 0] = image_id
            self.image_ids.append(image_id)
            self.detections.extend(valid_detection)

            # print('pred mask shape', pred_masks.shape)
            pred_mask = pred_masks[i]
            valid_mask = pred_mask[indices]
            # print('valid pred mask shape', valid_mask.shape)
            self.masks.extend(valid_mask)

            # seg_result_list = []
            # for det, mask in zip(valid_detection, valid_mask):
            #     seg_result_list.append(
            #         {
            #             'image_id': int(det[0]),
            #             'category_id': int(det[6]),
            #             'segmentation': self._RleCompress(mask),
            #             'score': float(np.around(det[5], decimals=3)),
            #         }
            #     )
            #
            # json.encoder.FLOAT_REPR = lambda o: format(o, '.3f')
            # output_path = self.out_json_file
            # logging.info('Writing output json file to: %s', output_path)
            # with tf.io.gfile.GFile(output_path, 'wb') as fid:
            #     json.dump(seg_result_list, fid)

            self.image_id += 1

    def estimator_metric_fn(self, detections, groundtruth_data, pred_masks=None, gt_masks=None):
        """Constructs the metric function for tf.TPUEstimator.

        For each metric, we return the evaluation op and an update op; the update op
        is shared across all metrics and simply appends the set of detections to the
        `self.detections` list. The metric op is invoked after all examples have
        been seen and computes the aggregate COCO metrics. Please find details API
        in: https://www.tensorflow.org/api_docs/python/tf/contrib/learn/MetricSpec
        Args:
          detections: Detection results in a tensor with each row representing
            [image_id, x, y, width, height, score, class]
          groundtruth_data: Groundtruth annotations in a tensor with each row
            representing [y1, x1, y2, x2, is_crowd, area, class].
        Returns:
          metrics_dict: A dictionary mapping from evaluation name to a tuple of
            operations (`metric_op`, `update_op`). `update_op` appends the
            detections for the metric to the `self.detections` list.
        """

        with tf.name_scope('coco_mask_metric'):
            if self.testdev_dir:
                update_op = tf.py_func(self.update_op, [detections, groundtruth_data], [])
                metrics = tf.py_func(self.result, [], tf.float32)
                metrics_dict = {'AP': (metrics, update_op)}
                return metrics_dict
            else:
                update_op = tf.py_func(self.update_op, [detections, pred_masks], [])
                metrics = tf.py_func(self.result, [], tf.float32)
                metrics_dict = {}
                for i, name in enumerate(self.mask_metric_names):
                    metrics_dict[name] = (metrics[i], update_op)
                return metrics_dict
